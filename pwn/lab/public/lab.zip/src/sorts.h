#include <stddef.h>
#ifndef SORTS_H
#define SORTS_H

void swap(void *, void*, size_t);
void dss(void *, size_t, size_t, int(*)(const void*,const void *));

#endif
