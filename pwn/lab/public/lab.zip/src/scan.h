#include <stdio.h>
#ifndef SCAN_H
#define SCAN_H
int scani(int *);
int fscani(int *, FILE*);
int scanF(float *);
char *freadline(FILE *text);
#endif /*SCAN_H*/
